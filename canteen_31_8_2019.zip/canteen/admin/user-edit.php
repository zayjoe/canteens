<?php include 'layouts/header.php';?>

  <div id="content-wrapper">
    <div class="container-fluid">

        <?php
            include("confs/auth.php");
            include("confs/config.php");
            $id = $_GET['id'];
            $result = mysqli_query($conn, "SELECT * FROM users WHERE id = $id");
            $row = mysqli_fetch_assoc($result);
        ?>

      <div class=" col-sm-8 text-left">

        <form action="user-update.php"class="fun_add" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
            <label for="name">Name</label>
            <input type="text" name="name" id="name" value="<?php echo $row['name']; ?>">
            <label for="remark">Email</label>
            <input name="email" id="email" value="<?php echo $row['email']; ?>">


            <br><br>
            <input type="submit" value="Update User">
        </form>

      </div>


    </div>
  </div>

<?php include 'layouts/footer.php';?>


