<?php
include("confs/auth.php");
include 'layouts/header.php';?>

  <div id="content-wrapper">
    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="#">Dashboard</a>
        </li>
        <li class="breadcrumb-item active">Products</li>
      </ol>

      <div class="col-sm-8">

      <form action="product-add.php" method="post" enctype="multipart/form-data">

        <div class="form-group">
            <label for="name">Product Name</label>
            <input type="text" name="title" class="form-control" placeholder="Enter Product">
        </div>

        <div class="form-group">
            <label for="exampleFormControlTextarea1">Body</label>
            <textarea name="body" class="form-control" id="exampleFormControlTextarea1" rows="3"></textarea>
        </div>

        <div class="form-group">
            <label for="name">Price</label>
            <input type="text" name="price" class="form-control" placeholder="Enter Price">
        </div>

        <div class="form-group">
            <label for="categories">Canteens</label>
            <select class="form-control" name="canteen_id" id="canteens">
                <option value="0">-- Choose --</option>
                <?php include("confs/config.php");
                    $result = mysqli_query($conn, "SELECT id, name FROM canteens");
                    while($row = mysqli_fetch_assoc($result)):
                ?>
                <option value="<?php echo $row['id'] ?>">
                <?php echo $row['name'] ?>
                </option>
                <?php endwhile; ?>
            </select>
        </div>

        <div class="form-group">
          <label for="get_in_time">Breakfast or Lunch</label>
          <select class="form-control" name="amOrpm" id="">
            <option value="Breakfast">Breakfast</option>
            <option value="Lunch">Lunch</option>
          </select>
        </div>

        <div class="form-group">
            <label for="image">Image</label>
            <input type="file" class="form-control-file form-control-lg" name="image" id="image">
        </div>


        <br><br>
        <input type="submit" class="btn btn-success" value="Add Product">
        <br><br>
      </form>
      </div>


    </div>
  </div>

<?php include 'layouts/footer.php';?>


