<?php
    session_start();
    include("admin/confs/config.php");

    $name = $_POST['name'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM `users` WHERE name='$name' ";

    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if(password_verify($password, $row['password'])) {
            if($row['is_admin'] == 0){
                $_SESSION['auth_user'] = $row['id'];
                header("location: index.php");
                //echo 'ok';
            }else {
                echo 'Please register first';
            }
        }
    }


?>
