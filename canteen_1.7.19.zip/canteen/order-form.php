<?php include 'header.php';

//echo($_SESSION['total_price']);
//$discount = $_POST['dis_points'];
//echo $discount;
 $dis_points = $_POST['discount_point'];
    //echo $dis_points;
$_SESSION['discount'] = $dis_points;
?>
<div class="container">
    <div class="row">
        <div class="col-8">
            <div class="order-form">
                <h2>Order Now</h2>
                <form action="submit-order.php" method="post">
                    <div class="form-group">
                        <label for="name">Your Name</label>
                        <input type="text" class="form-control" name="name" id="name">
                    </div>

                    <div class="form-group">
                        <label for="email">Email</label>
                        <input type="text" class="form-control" name="email" id="email">
                    </div>

                    <div class="form-group">
                        <label for="phone">Phone</label>
                        <input type="text" class="form-control" name="phone" id="phone">
                    </div>

                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea name="address" class="form-control" rows="3" id="address"></textarea>
                    </div>

                    <br><br>
                    <input class="btn btn-primary" type="submit" value="Submit Order">

                </form>
            </div>
        </div>
    </div>
</div>
<?php include 'footer.php' ?>