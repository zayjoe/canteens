<?php
    include("confs/auth.php");
    include("confs/config.php");
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $sql = "UPDATE users SET name='$name', email='$email', update_at=now() WHERE id = '$id' ";
    mysqli_query($conn, $sql);
    header("location: user-list.php");
?>
