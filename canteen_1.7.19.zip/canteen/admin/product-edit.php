<?php
    include("confs/auth.php");
    include 'layouts/header.php';
?>

<?php
    include("confs/config.php");
    $id = $_GET['id'];
    $sql = "SELECT * FROM products WHERE id = $id";
    $result = mysqli_query($conn, $sql);
    $row = mysqli_fetch_assoc($result);
    //var_dump($row);
?>

  <div id="content-wrapper">
    <div class="container-fluid">

      <!-- Breadcrumbs-->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          Dashboard
        </li>
        <li class="breadcrumb-item active">Products Edit</li>
      </ol>

      <div class="col-sm-8">

      <form action="product-update.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
        <div class="form-group">
            <label for="name">Product Name</label>
            <input type="text" name="title" class="form-control" placeholder="Enter Product" value="<?php echo $row['title'] ?>">
        </div>

        <div class="form-group">
            <label for="exampleFormControlTextarea1">Body</label>
            <textarea name="body" class="form-control" id="exampleFormControlTextarea1" rows="3">
                <?php echo $row['body'] ?>
            </textarea>
        </div>

        <div class="form-group">
            <label for="name">Price</label>
            <input type="text" name="price" class="form-control" placeholder="Enter Price" value="<?php echo $row['price']?>">
        </div>

        <div class="form-group">
            <label for="categories">Canteens</label>
            <select class="form-control" name="canteen_id" id="canteens">
                <?php include("confs/config.php");
                    $can = mysqli_query($conn, "SELECT id, name FROM canteens");
                    while($row_can = mysqli_fetch_assoc($can)):
                ?>
                <option value="<?php echo $row_can['id'] ?>">
                <?php echo $row_can['name'] ?>
                </option>
                <?php endwhile; ?>
            </select>
        </div>


        <div class="form-group">
            <label for="image">Image</label>
            <img src="./images/<?php echo $row['image'] ?>" alt="" class="img-thumnail" style="width:15%;">
            <input type="file" class="form-control-file form-control-lg" name="image" id="image">
        </div>


        <br><br>
        <input type="submit" class="btn btn-success" value="Update Product">
        <br><br>
      </form>
      </div>


    </div>
  </div>

<?php include 'layouts/footer.php';?>


