<?php
	//session_start();
	include 'header.php';
	include("admin/confs/config.php");

	$total = $_SESSION['total'];

	$discount = ($_SESSION['discount']);

	$name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $sqlOrder = "INSERT INTO orders (name,email,phone,address,status,create_at,update_at) VALUES ('$name','$email','$phone','$address',0,now(),now())";
    mysqli_query($conn, $sqlOrder);

    $order_id = mysqli_insert_id($conn);
    foreach($_SESSION['cart'] as $id => $qty) {
        $sqlOrederItems = "INSERT INTO order_items (order_id,product_id,qty) VALUES ('$order_id','$id','$qty')";
        mysqli_query($conn, $sqlOrederItems);
    }


	if($discount == 0){
		if($total > 5000){
			$units = floor($total / 5000);
			$points = $units * 30;

			$user_id = $_SESSION['auth_user'];
			$getPointsQuery = "SELECT * FROM points WHERE user_id = '$user_id'";
			$result = mysqli_query($conn, $getPointsQuery);
			$row = mysqli_fetch_assoc($result);
			if ($row) {
				$existing_points = $row['points'];
				$new_points = $existing_points + $points;
				$updatePointsQuery = "UPDATE points SET points = '$new_points' WHERE user_id = '$user_id'";
				$result = mysqli_query($conn, $updatePointsQuery);
				// if ($result) {
				// 	echo "updated";
				// } else {
				// 	echo "error";
				// }
			} else {
				$insertPointsQuery = "INSERT INTO points (user_id,points,create_at,update_at) VALUES ('$user_id','$points',now(),now())";
				$result = mysqli_query($conn, $insertPointsQuery);
				// if ($result) {
				// 	echo "indserte";
				// } else {
				// 	echo "error";
				// }

			}



			// $sql = "INSERT INTO points (user_id,points,create_at,update_at) VALUES ('$user_id','$points',now(),now())";
			// mysqli_query($conn, $sql);


		}
		 unset($_SESSION['cart']);

	}elseif($discount == 100) {
		if($total > 5000){
			$units = floor($total / 5000);
			$points = $units * 30;

			$user_id = $_SESSION['auth_user'];
			$getPointsQuery = "SELECT * FROM points WHERE user_id = '$user_id'";
			$result = mysqli_query($conn, $getPointsQuery);
			$row = mysqli_fetch_assoc($result);
			if ($row) {
				$existing_points = $row['points'];
				$new_points = ($existing_points + $points) - 100;
				$updatePointsQuery = "UPDATE points SET points = '$new_points' WHERE user_id = '$user_id'";
				$result = mysqli_query($conn, $updatePointsQuery);
			}


		}elseif($total < 5000){
			$user_id = $_SESSION['auth_user'];
			$getPointsQuery = "SELECT * FROM points WHERE user_id = '$user_id'";
			$result = mysqli_query($conn, $getPointsQuery);
			$row = mysqli_fetch_assoc($result);
			if ($row) {
				$existing_points = $row['points'];
				$new_points = $existing_points - 100;
				$updatePointsQuery = "UPDATE points SET points = '$new_points' WHERE user_id = '$user_id'";
				$result = mysqli_query($conn, $updatePointsQuery);
			}


		}
		unset($_SESSION['cart']);

	}



?>
<div class="container">
	<div class="row">
		<div class="col-md-2"></div>
		<div class="col-md-8">
			<h1>Order Submitted</h1>
			<div class="msg">
				Your order has been submitted. We'll deliver the items soon.
				<a href="index.php" class="done">Home</a>
			</div>
		</div>
		<div class="col-md-2"></div>
	</div>
</div>


<?php include 'footer.php' ?>