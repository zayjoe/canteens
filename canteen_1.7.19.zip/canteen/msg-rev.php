<?php
//include("admin/confs/auth.php");
    include 'header.php';
    if(isset($_SESSION['auth_user'])){
        //echo ($_SESSION['auth_user']);
    }
?>
<div class="container">
    <div class="col-md-6">
        <div class="well">Thank you for your interest. we will contact you soon.</div>
        <button class="btn btn-primary"><a class="text-white" href="index.php">Back to HOME</a></button>
        <br><br>
    </div>
</div>


<?php include 'footer.php';?>