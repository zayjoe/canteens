<?php include 'layouts/header.php';?>

  <div id="content-wrapper">
    <div class="container-fluid">

        <?php
            include("confs/auth.php");
            include("confs/config.php");
            $id = $_GET['id'];
            $result = mysqli_query($conn, "SELECT * FROM points WHERE id = $id");
            $row = mysqli_fetch_assoc($result);
        ?>

      <div class=" col-sm-8 text-left">

        <form action="point-update.php"class="fun_add" method="post">
        <input type="hidden" name="id" value="<?php echo $row['id'] ?>">
            <label for="name">Points</label>
            <input type="text" name="points" id="name" value="<?php echo $row['points']; ?>">

            <br><br>
            <input type="submit" value="Update Points">
        </form>

      </div>


    </div>
  </div>

<?php include 'layouts/footer.php';?>


