<?php
//include("admin/confs/auth.php");
    include 'header.php';
    if(isset($_SESSION['auth_user'])){
        //echo ($_SESSION['auth_user']);
    }
?>
<section id="success">
	<div class="container">
		<div class="row">
			<div class="col-md-12">
				<div class="products-heading">
					<h2>Thank You</h2>
				</div>
			</div>
		</div>
		<div class="col-sm-2"></div>

		<!-- Section start -->
		<div class="col-sm-8">
			<div class="succes_body">
				<h1 class="success_title">Your order is success.</h1>
				<p class="success_txt">
					Your order has been seccessed. We'll deliver the foods soon and you will get
					<span class="point_txt">( 30 )</span> points into your account.
				</p>
				<a href="index.php"><button class="btn btn-success success_btn">Go to Home</button></a>
			</div>
		</div> <!-- End of col-sm-8 -->
		<div class="col-sm-2"></div>
	</div>
</section>


<?php include 'footer.php';?>