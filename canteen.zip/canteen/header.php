<?php
	 session_start();
	// $login_user = $_SESSION['auth'];
	//echo ($_SESSION['auth']);
	//include("admin/confs/auth_user.php");

	include("admin/confs/config.php");

	$cart = 0;
	if(isset($_SESSION['cart'])) {
		foreach($_SESSION['cart'] as $qty) {
		$cart += $qty;
		}
	}

	if(isset($_GET['cat'])) {
		$cat_id = $_GET['cat'];
		$products = mysqli_query($conn, "SELECT * FROM products WHERE canteen_id =
		$cat_id");
	} else {
		$products = mysqli_query($conn, "SELECT * FROM products");
	}
	$products1 = mysqli_query($conn, "SELECT * FROM products WHERE canteen_id = 1");
	$products2 = mysqli_query($conn, "SELECT * FROM products WHERE canteen_id = 2");
	$products3 = mysqli_query($conn, "SELECT * FROM products WHERE canteen_id = 3");
	$products4 = mysqli_query($conn, "SELECT * FROM products WHERE canteen_id = 4");
	$canteen = mysqli_query($conn, "SELECT * FROM canteens");

	if(isset($_SESSION['auth_user'])){
		$uid =  ($_SESSION['auth_user']);

		$result = mysqli_query($conn, "SELECT * FROM `users` WHERE id = $uid;");
		$user = mysqli_fetch_assoc($result);

		$points = mysqli_query($conn, "SELECT * FROM `points` WHERE user_id = $uid;");
		$user_points = mysqli_fetch_assoc($points);
	}

?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Food Code Proudly Presents By Themexpert</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<!-- Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,700' rel='stylesheet' type='text/css'>

	<!-- Css -->
	<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" />
	<link rel="stylesheet" href="css/owl.carousel.css">
	<link rel="stylesheet" href="css/owl.theme.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">

	<!-- jS -->
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.nivo.slider.js" type="text/javascript"></script>
	<script src="js/owl.carousel.min.js" type="text/javascript"></script>
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/jquery.validate.min.js"></script>
	<script src="js/main.js" type="text/javascript"></script>


</head>
<body>
    <!-- TOP HEADER Start
    ================================================== -->

	<section id="top">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<p class="contact-action"><i class="fa fa-phone-square"></i>IN CASE OF ANY QUESTIONS, CALL THIS NUMBER: <strong>09262606265</strong></p>
				</div>
				<div class="col-md-5 clearfix">
					<ul class="login-cart">

					</ul>
				</div>
			</div> <!-- End Of /.row -->
		</div>	<!-- End Of /.Container -->


	<!-- MODAL Start
    	================================================== -->

    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Introduce Yourself</h4>
                </div>
                <div class="modal-body clearfix">

                    <form action="register.php" method="post" id="create-account_form" class="std">
                        <fieldset>
                            <h3>Create your account</h3>
                            <div class="form_content clearfix">
                                <p class="text">
                                    <label for="name_name">User Name</label>
                                    <span>
                                        <input placeholder="User Name"  type="text" id="reg_name" name="reg_name" value="" class="account_input">
                                    </span>
                                </p>
                                <p class="text">
                                    <label for="email">Email Address</label>
                                    <span>
                                        <input placeholder="E-mail Address"  type="text" id="reg_email" name="reg_email" value="" class="account_input">
                                    </span>
                                </p>
                                <p class="text">
                                    <label for="password">User Name</label>
                                    <span>
                                        <input placeholder="Password"  type="password" id="reg_password"  name="reg_password" value="" class="account_input">
                                    </span>
                                </p>

                                <p class="submit">
                                    <button type="submit" class="btn btn-primary">Create Your Account</button>
                                </p>
                            </div>
                        </fieldset>
                    </form>
                    <form action="login.php" method="post" id="login_form" class="std">
                        <fieldset>
                            <h3>Already registered?</h3>
                            <div class="form_content clearfix">
                                <p class="text">
                                <label for="user_name">User Name</label>
                                    <span><input placeholder="User Name" type="text" id="name" name="name" value="" class="account_input"></span>
                                </p>
                                <p class="text">
                                <label for="password">Password</label>
                                    <span><input placeholder="Password" type="password" id="password"  name="password" value="" class="account_input"></span>
                                </p>
                                <p class="lost_password">
                                    <a href="#popab-password-reset" class="popab-password-link">Forgot your password?</a>
                                </p>
                                <p class="submit">
                                    <button type="submit" class="btn btn-success">Log in</button>
                                </p>
                            </div>
                        </fieldset>
                    </form>
				</div>
				<div class="modal" id="loginModal" tabindex="-1" role="dialog">
					<div class="modal-dialog" role="document">
						<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title text-danger">Fail</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<div class="modal-body">
							<p class="text-danger">Email or password is wrong.</p>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
						</div>
						</div>
					</div>
        	</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
	</section>  <!-- End of /Section -->



	<!-- LOGO Start
    ================================================== -->

	<header>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<a href="#">
						<img src="images/logo.png" alt="logo">
					</a>
				</div>	<!-- End of /.col-md-12 -->
			</div>	<!-- End of /.row -->
		</div>	<!-- End of /.container -->
	</header> <!-- End of /Header -->




	<!-- MENU Start
    ================================================== -->

	<nav class="navbar navbar-default">
		<div class="container">
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		    </div> <!-- End of /.navbar-header -->

		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      	<ul class="nav navbar-nav nav-main">
		      		<li class="active"><a href="index.php">Home</a></li>
		      		<li class="dropdown">
						<a href="#">
							Canteens
							<span class="caret"></span>
						</a>

						<ul class="dropdown-menu">
						<?php while($row = mysqli_fetch_assoc($canteen)): ?>
							<li><a href="index.php?cat=<?php echo $row['id']; ?>"><?php echo $row['name']; ?></a></li>
						<?php endwhile; ?>

						   <!-- <li><a  href="canteen-1.php">Canteen One</a></li>
						    <li><a  href="canteen-2.php">Canteen Two</a></li>
						    <li><a  href="canteen-3.php">Canteen Three</a></li>
						    <li><a  href="canteen-4.php">Canteen Four</a></li> -->
						</ul>
					</li>
					<li><a href="contact-us.php">Contact Us</a></li>
					<li><a href="about-us.php">About Us</a></li>
					<?php  if(isset($_SESSION['auth_user'])):?>
					<li>
						<span>
								<span><?php echo $user['name']; ?></span>  Dis point:<span>( <?php echo $user_points['points'] ?> )</span>
						</span>
					</li>
					<?php endif; ?>
					<?php  if(!isset($_SESSION['auth_user'])):?>
					<li>
							<a data-toggle="modal" data-target="#myModal" href="#">
							<i class="fa fa-user"></i>
								Login
							</a>
					</li>
					<?php endif; ?>
					<?php  if(isset($_SESSION['auth_user'])):?>
					<li>
						<div class="cart dropdown">
							<?php
							if(isset($_SESSION['cart'])): ?>

								<a href="view-cart.php"><i class="fa fa-shopping-cart">
							<?php else: ?>

								<a href="#"><i class="fa fa-shopping-cart">
							<?php endif; ?>
							</i>Cart(<span id="cartNumber"><?php echo $cart; ?></span>)</a>
						</div>
					</li>
					<?php endif; ?>

					<?php  if(isset($_SESSION['auth_user'])):?>
					<li>
							<a  href="logout.php">
							<i class="fa fa-user"></i>
								logout
							</a>
					</li>
					<?php endif; ?>


					<!-- <li><a href="blog-single.php">ARTICLE</a></li> -->

					<!-- End of /.dropdown -->


		        </ul> <!-- End of /.nav-main -->
		    </div>	<!-- /.navbar-collapse -->
		</div>	<!-- /.container-fluid -->
	</nav>	<!-- End of /.nav -->
