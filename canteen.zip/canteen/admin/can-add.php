<?php
  include("confs/auth.php");
  include("confs/config.php");
  $name = $_POST['name'];
  $remark = $_POST['remark'];
  $sql = "INSERT INTO canteens (name,remark,create_at,update_at) VALUES ('$name','$remark',now(),now())";
  mysqli_query($conn, $sql);
  header("location: can-list.php");
?>

