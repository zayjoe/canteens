<?php
$dbhost = "localhost";
$dbuser = "root";
$dbpass = "";
$dbname = "canteen_db";

// Create connection
$conn = mysqli_connect($dbhost, $dbuser, $dbpass);
mysqli_select_db($conn, $dbname);
// Check connection
// if ($conn->connect_error) {
//     die("Connection failed: " . $conn->connect_error);
// }
// echo "Connected successfully";
?>