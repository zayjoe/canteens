<?php
    session_start();
    if(!isset($_SESSION['auth_user'])) {
     //$login_user = true;
     //header("location: index.php");
    exit();
    }
?>