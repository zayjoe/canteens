<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Canteen Food - Dashboard</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">

    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link rel="icon" href="favicon.png" type="image/x-icon"/>
    <link href="css/sb-admin.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">


  </head>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg_green static-top">

      <a class="navbar-brand mr-1" href="can-list.php">Canteen Food</a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>
      </button>


      <!-- Navbar -->
      <ul class="nav ml-auto">
        <li class="">
          <a class="nav-link" href="logout.php">
            <i class="fas fa-sign-out-alt"></i>
          </a>
        </li>
      </ul>
    </nav>
    <div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item ">
          <a class="nav-link" href="user-list.php">
            <i class="fa fa-user"></i>
            <span>User</span>
          </a>
        </li>
        <li class="nav-item ">
          <a class="nav-link" href="product-list.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Food</span>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link" href="can-list.php">
            <i class="fas fa-chart-pie"></i>
            <span>Canteen</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="orders.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Orders</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="orders.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Point</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="contact-list.php">
            <i class="fas fa-mail-bulk"></i>
            <span>Contact</span></a>
        </li>

      </ul>
