<?php
    include("confs/auth.php");
    include 'layouts/header.php';
?>
<div id="content-wrapper">
    <div class="container-fluid">
    <a href="product-new.php" class="new btn add_btn"><i class="fas fa-plus-circle"></i>New Product</a>

    <!-- Here Start the list of canteens -->
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>#</th>
              <th>Product Name</th>
              <th>Body</th>
              <th>Price</th>
              <th>Canteen</th>
              <th>Delete</th>
              <th>Edit</th>
            </tr>
          </thead>
          <?php
            include("confs/config.php");
            $sql = "SELECT products.*,canteens.name FROM products LEFT JOIN canteens ON products.canteen_id = canteens.id
            ORDER BY products.create_at DESC";
            $result = mysqli_query($conn, $sql);
          ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
           <?//php var_dump($row); ?>
          <tr>
            <td style="width:15%;"><img src="./images/<?php echo $row['image']; ?>"  class="img-thumbnail"></td>
            <td><?php echo $row['title'] ?></td>
            <td><?php echo $row['body'] ?></td>
            <td><?php echo $row['price'] ?></td>
            <td><?php echo $row['name'] ?></td>
            <td><a href="product-delete.php?id=<?php echo $row['id'] ?>"><button class="del_btn btn danger"> <i class="fas fa-trash-alt"></i> Delete</button></a></td>
            <td><a href="product-edit.php?id=<?php echo $row['id'] ?>"><button class="edit_btn btn info"><i class="far fa-edit"></i>Edit</button></a> </td>
          </tr>
          <?php endwhile; ?>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
    <!-- Here End the list of canteens -->
    </div>
  </div>
<?php include 'layouts/footer.php';?>
