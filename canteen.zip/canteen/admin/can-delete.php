<?php
    include("confs/auth.php");
    include("confs/config.php");
    $id = $_GET['id'];
    $sql = "DELETE FROM canteens WHERE id = $id";
    mysqli_query($conn, $sql);
    header("location: can-list.php");
?>
