<?php
    session_start();
    include("confs/config.php");

    $name = $_POST['name'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM `users` WHERE name='$name' ";

    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        if(password_verify($password, $row['password'])) {
            if($row['is_admin']){
                $_SESSION['auth'] = true;
                header("location: can-list.php");
            }else {
                header("location: index.php");
            }
        }
    }

    // if($name == "admin" and $password == "1234") {
    // $_SESSION['auth'] = true;
    // header("location: can-list.php");
    // } else {
    // header("location: index.php");
    // }


?>
