<?php
  include("confs/auth.php");
  include 'layouts/header.php';
?>

  <div id="content-wrapper">
    <div class="container-fluid">
    <a href="can-new.php" class="new btn add_btn"><i class="fas fa-plus-circle"></i>New Canteen</a>

    <!-- Here Start the list of canteens -->
    <div class="card-body">
      <div class="table-responsive">
        <table class="table table-bordered text-center" width="100%" cellspacing="0">
          <thead>
            <tr>
              <th>Name</th>
              <th>Remark</th>
              <th>Delete</th>
              <th>Edit</th>
            </tr>
          </thead>
          <?php
            include("confs/config.php");
            $result = mysqli_query($conn, "SELECT * FROM canteens");
          ?>
          <?php while($row = mysqli_fetch_assoc($result)): ?>
          <tr>
            <td><?php echo $row['name'] ?></td>
            <td><?php echo $row['remark'] ?></td>
            <td><a href="can-delete.php?id=<?php echo $row['id'] ?>"><button class="del_btn btn danger"> <i class="fas fa-trash-alt"></i> Delete</button></a></td>
            <td><a href="can-edit.php?id=<?php echo $row['id'] ?>"><button class="edit_btn btn info"><i class="far fa-edit"></i>Edit</button></a> </td>
          </tr>
          <?php endwhile; ?>
          <tbody>

          </tbody>
        </table>
      </div>
    </div>
    <!-- Here End the list of canteens -->
    </div>
  </div>

<?php include 'layouts/footer.php';?>
