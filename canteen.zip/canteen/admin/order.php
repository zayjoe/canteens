<?php
    include("confs/auth.php");
    include 'layouts/header.php';

?>
<div class="container">
<h1>Order List</h1>

    <div class="row">
        <?php
            include("confs/config.php");
            $orders = mysqli_query($conn, "SELECT * FROM orders");
        ?>
        <?php while($order = mysqli_fetch_assoc($orders)): ?>
            <div class="col-md-6">
                <h3>Customer</h3>
                <p><?php echo $order['name'] ?></p>
                <p><?php echo $order['email'] ?></p>
                <p><?php echo $order['phone'] ?></p>
                <p><?php echo $order['address'] ?></p>
                <?php if($order['status']): ?>
                * <a href="order-status.php?id=<?php echo $order['id'] ?>&status=0">
                Undo</a>
                <?php else: ?>
                * <a href="order-status.php?id=<?php echo $order['id'] ?>&status=1">
                Mark as Delivered</a>
                <?php endif; ?>
            </div>
            <div class="col-md-6">
                <h3>Order items</h3>
                <?php
                    $order_id = $order['id'];
                    $items = mysqli_query($conn, "SELECT order_items.*, products.title
                    FROM order_items LEFT JOIN products ON order_items.product_id = products.id
                    WHERE order_items.order_id = $order_id
                    ");
                    while($item = mysqli_fetch_assoc($items)):
                    ?>
                    <b>
                    <a href="../book-detail.php?id=<?php echo $item['book_id'] ?>">
                        <?php echo $item['title'] ?>
                    </a>
                    (<?php echo $item['qty'] ?>)
                    </b>
                    <?php endwhile;
                ?>

            </div>
        <?php endwhile; ?>
    </div>
</div>
<?php include 'layouts/footer.php';?>
