<?php
    session_start();
    include("admin/confs/config.php");

    $cart = 0;

    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $address = $_POST['address'];

    $sql = "INSERT INTO orders (name,email,phone,address,status,create_at,update_at) VALUES ('$name','$email','$phone','$address',0,now(),now())";
    mysqli_query($conn, $sql);

    $order_id = mysqli_insert_id($conn);
    foreach($_SESSION['cart'] as $id => $qty) {
        $sql = "INSERT INTO order_items (order_id,product_id,qty) VALUES ('$order_id','$id','$qty')";
        mysqli_query($conn, $sql);
    }
    unset($_SESSION['cart']);
?>
<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Food Code Proudly Presents By Themexpert</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">

	<!-- Fonts -->
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:400,300,600,700' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,700' rel='stylesheet' type='text/css'>

	<!-- Css -->
	<link rel="stylesheet" href="css/nivo-slider.css" type="text/css" />
	<link rel="stylesheet" href="css/owl.carousel.css">
	<link rel="stylesheet" href="css/owl.theme.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">
	<link rel="stylesheet" href="css/font-awesome.css">
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/style.css">
	<link rel="stylesheet" href="css/responsive.css">

	<!-- jS -->
	<script src="js/jquery.min.js" type="text/javascript"></script>
	<script src="js/bootstrap.min.js" type="text/javascript"></script>
	<script src="js/jquery.nivo.slider.js" type="text/javascript"></script>
	<script src="js/owl.carousel.min.js" type="text/javascript"></script>
	<script src="js/jquery.nicescroll.js"></script>
	<script src="js/jquery.scrollUp.min.js"></script>
	<script src="js/main.js" type="text/javascript"></script>


</head>
<body>
    <!-- TOP HEADER Start
    ================================================== -->

	<section id="top">
		<div class="container">
			<div class="row">
				<div class="col-md-7">
					<p class="contact-action"><i class="fa fa-phone-square"></i>IN CASE OF ANY QUESTIONS, CALL THIS NUMBER: <strong>09420253928</strong></p>
				</div>
				<div class="col-md-5 clearfix">
					<ul class="login-cart">

					</ul>
				</div>
			</div> <!-- End Of /.row -->
		</div>	<!-- End Of /.Container -->


	<!-- MODAL Start
    	================================================== -->

    <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title" id="myModalLabel">Introduce Yourself</h4>
                </div>
                <div class="modal-body clearfix">

                    <form action="register.php" method="post" id="create-account_form" class="std">
                        <fieldset>
                            <h3>Create your account</h3>
                            <div class="form_content clearfix">
                                <p class="text">
                                    <label for="name_name">User Name</label>
                                    <span>
                                        <input placeholder="User Name"  type="text"  name="user_name" value="" class="account_input">
                                    </span>
                                </p>
                                <p class="text">
                                    <label for="email">Email Address</label>
                                    <span>
                                        <input placeholder="E-mail Address"  type="text"  name="email" value="" class="account_input">
                                    </span>
                                </p>
                                <p class="text">
                                    <label for="password">User Name</label>
                                    <span>
                                        <input placeholder="Password"  type="password"  name="password" value="" class="account_input">
                                    </span>
                                </p>

                                <p class="submit">
                                    <button class="btn btn-primary">Create Your Account</button>
                                </p>
                            </div>
                        </fieldset>
                    </form>
                    <form action="login.php" method="post" id="login_form" class="std">
                        <fieldset>
                            <h3>Already registered?</h3>
                            <div class="form_content clearfix">
                                <p class="text">
                                <label for="user_name">User Name</label>
                                    <span><input placeholder="User Name" type="text" name="name" value="" class="account_input"></span>
                                </p>
                                <p class="text">
                                <label for="password">Password</label>
                                    <span><input placeholder="Password" type="password"  name="password" value="" class="account_input"></span>
                                </p>
                                <p class="lost_password">
                                    <a href="#popab-password-reset" class="popab-password-link">Forgot your password?</a>
                                </p>
                                <p class="submit">
                                    <button class="btn btn-success">Log in</button>
                                </p>
                            </div>
                        </fieldset>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
	</section>  <!-- End of /Section -->



	<!-- LOGO Start
    ================================================== -->

	<header>
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<a href="#">
						<img src="images/logo.png" alt="logo">
					</a>
				</div>	<!-- End of /.col-md-12 -->
			</div>	<!-- End of /.row -->
		</div>	<!-- End of /.container -->
	</header> <!-- End of /Header -->




	<!-- MENU Start
    ================================================== -->

	<nav class="navbar navbar-default">
		<div class="container">
		    <div class="navbar-header">
		      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
		        <span class="sr-only">Toggle navigation</span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		        <span class="icon-bar"></span>
		      </button>
		    </div> <!-- End of /.navbar-header -->

		    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
		      	<ul class="nav navbar-nav nav-main">
		      		<li class="active"><a href="#">Home</a></li>
		      		<li class="dropdown">
						<a href="#">
							Canteens
							<span class="caret"></span>
						</a>
						<ul class="dropdown-menu">
						   <li><a  href="canteens.php">Canteen One</a></li>
						    <li><a  href="#">Canteen Two</a></li>
						    <li><a  href="#">Canteen Three</a></li>
						    <li><a  href="#">Canteen Four</a></li>
						</ul>
					</li>
					<li><a href="contact_us.php">Contact Us</a></li>
					<li><a href="about_us.php">About Us</a></li>
											<li>
							<a data-toggle="modal" data-target="#myModal" href="#">
							<span>
								<span>User Name </span>Dis point:<span>( 09 )</span>
							</span>
							<i class="fa fa-user"></i>
								Login
							</a>
						</li>
						<li>
							<div class="cart dropdown">
						  		<a href="view-cart.php"><i class="fa fa-shopping-cart"></i>Cart(<?php echo $cart; ?>)</a>
							</div>
						</li>
					<!-- <li><a href="blog-single.php">ARTICLE</a></li> -->

					<!-- End of /.dropdown -->


		        </ul> <!-- End of /.nav-main -->
		    </div>	<!-- /.navbar-collapse -->
		</div>	<!-- /.container-fluid -->
	</nav>	<!-- End of /.nav -->

    <h1>Order Submitted</h1>
    <div class="msg">
        Your order has been submitted. We'll deliver the items soon.
        <a href="index.php" class="done">Home</a>
    </div>

<?php include 'footer.php' ?>