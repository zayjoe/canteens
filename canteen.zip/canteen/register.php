<?php
  include("admin/confs/config.php");
  $user_name = $_POST['user_name'];
  $email = $_POST['email'];
  $password = $_POST['password'];
  $pass = password_hash($password, PASSWORD_DEFAULT);
  //echo $pass;
  $sql = "INSERT INTO users (name,email,password,create_at,update_at) VALUES ('$user_name','$email','$pass',now(),now())";
  mysqli_query($conn, $sql);
  header("location: index.php");
?>