<?php
  session_start();
  include("admin/confs/config.php");
  // $user_name = $_POST['user_name'];
  // $email = $_POST['email'];
  // $password = $_POST['password'];
  // $pass = password_hash($password, PASSWORD_DEFAULT);
  // //echo $pass;
  // $sql = "INSERT INTO users (name,email,password,create_at,update_at) VALUES ('$user_name','$email','$pass',now(),now())";
  // mysqli_query($conn, $sql);
  // $user_id = mysqli_insert_id($conn);
  // $_SESSION['auth_user'] = $user_id;
  // header("location: index.php");

  if(isset($_POST['reg_name'])){
    $name = $_POST['reg_name'];
    $password = $_POST['reg_password'];
    $email = $_POST['reg_email'];
    $pass =password_hash($password, PASSWORD_DEFAULT);
    $user_check = "SELECT * FROM users WHERE name = '$name' ";

     $result = mysqli_query($conn,$user_check);
     $count = mysqli_num_rows($result);

    if($count == 1){
        echo "usernameExit";
    }else {
        echo "Successfully";

        $user_add = "INSERT INTO users (name,email,password,create_at,update_at) VALUES ('$name','$email','$pass',now(),now())";
        mysqli_query($conn,$user_add);
        $user_id = mysqli_insert_id($conn);
        $_SESSION['auth_user'] = $user_id;
    }
}
?>